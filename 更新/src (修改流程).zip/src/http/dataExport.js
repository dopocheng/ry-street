import axios from "./index.js";

export function diskLetterApi(data) {//originalDcl/listRoot 获取盘符
    return axios({
        url: '/originalDcl/listRoot',
        method: 'post',
        params: data
    })
}

export function areaCopyApi(data) {//originalDcl/streetCopy 街景拷贝
    return axios({
        url: '/originalDcl/streetCopy',
        method: 'post',
        params: data
    })
}



export function dataCopyApi(data) {//originalDcl/streetIndexCopy
    return axios({
        url: '/originalDcl/streetIndexCopy',
        method: 'post',
        params: data
    })
}

export function dbIdApi(params) {//originalDcl/getStreetTableRegionByRegion
    console.log(22)
    return axios({
        url: "/originalDcl/getStreetTableRegionByRegion",
        method: 'get',
        params: params
    })
}

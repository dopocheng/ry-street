import axios from "./index.js";

export function areaAll(params) {
    return axios({
        url: "/originalDcl/getRegionAll",
        method: 'get',
        params: params
    })
}
export function areaDb(params) {
    return axios({
        url: "/originalDcl/getStreetTableRegionByRegion",
        method: 'get',
        params: params
    })
}


//yong  /originalDcl/deleteIndexDesignate 根据指定年份删除库中索引
export function yearDeleteApi(data) {///originalDcl/{ids}
    return axios({
        url: '/originalDcl/deleteIndexDesignate',
        method: 'post',
        data: data
    })
}


export function dataCopyApi(data) {///originalDcl/{ids}
    return axios({
        url: '/originalDcl/streetIndexCopy',
        method: 'post',
        params: data
    })
}
export function deleteApi(data) {///originalDcl/{ids}
    return axios({
        url: `/originalDcl/deleteById`,
        method:'post',
        data: data
    })
}
export function yearApi(data) {//1平方公里库范围街景点
    return axios({
        url: '/originalDcl/getStreetYear',
        method:'post',
        data: data
    })
}
export function streetApi(data) {//1平方公里库范围街景点 getStreetIndexAll
    return axios({
        url: '/originalDcl/getStreetIndexAll',
        method:'post',
        data: data
    })
}

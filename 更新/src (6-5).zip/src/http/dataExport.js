import axios from "./index.js";



export function dataCopyApi(data) {//originalDcl/streetIndexCopy
    return axios({
        url: '/originalDcl/streetIndexCopy',
        method: 'post',
        params: data
    })
}

export function dbIdApi(params) {//originalDcl/getStreetTableRegionByRegion
    console.log(22)
    return axios({
        url: "/originalDcl/getStreetTableRegionByRegion",
        method: 'get',
        params: params
    })
}

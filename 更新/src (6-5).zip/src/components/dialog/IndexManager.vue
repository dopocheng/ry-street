<template>
  <div>
    <el-dialog
      title="索引管理"
      draggable
      overflow
      :modal="false"
      :close-on-click-modal="false"
      v-model="isOpen"
      @close="handleClose"
    >
      <div class="area-mana">
        <p>选择范围：</p>
        <img
          style="width: 30px; height: 29px"
          src="../../assets/street/多边形.png"
          alt=""
          srcset=""
          @click="drawArea"
        />
      </div>
      <el-button @click="deleteArea">删除区域</el-button>
      <el-table border stripe :data="tableData" height="400" style="width: 100%">
        <el-table-column type="selection" width="55" />
        <el-table-column prop="id" label="id" align="center" width="180" />
        <el-table-column prop="tableName" label="库名" width="180" align="center" />
        <el-table-column prop="lon" label="经度" width="180" align="center" />
        <el-table-column prop="lat" label="纬度" align="center" />
        <el-table-column label="操作" align="center">
          <template #default="scope">
            <el-button
              size="small"
              type="primary"
              :disabled="scope.row.status == 1 ? true : false"
              @click="handleCopy(scope.$index, scope.row)"
            >
              索引拷贝
            </el-button>
            <el-button size="small" type="primary" @click="handleCheck(scope.row)">
              查看
            </el-button>
            <el-button size="small" type="primary" @click="handleDelete(scope)"> 删除 </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
    <el-button text style="position: fixed; z-index: 100; color: red" @click="table = true"
      >Open Drawer with nested table</el-button
    >
    <el-drawer
      modal-class="op"
      v-model="table"
      direction="rtl"
      size="100%"
      :with-header="true"
      :modal="false"
      style="right: inherit;padding-top: 0px !important"
    >
      <YC @ycSelectEmit="handlerEmit" />
    </el-drawer>
    <div v-if="menu" class="menu">
      <span>删除当前实体</span>
    </div>
  </div>
</template>
<script>
import { onMounted, ref, watch, inject, nextTick } from 'vue'
import { areaIdDb } from '../../api/tool.js'
import { areaAll, areaDb } from '../../http/indexMana.js'
import { dataCopyApi, deleteApi, yearApi, streetApi } from '../../http/indexMana.js'
import YC from '../../components/tool/YearColor.vue'
export default {
  components: { YC },
  props: {
    showView: Boolean
  },
  emits: ['closeEmit'],
  setup(props, ctx) {
    const menu = ref(false)//右键菜单显隐
    const table = ref(false)
    const isShow = ref(false)
    const currentRect = ref(null)
    const tableData = ref([])
    let isOpen = ref(null)
    let flag = ref(null)
    const cObj = inject('cObj') //地球页面 Obj

    watch(
      () => props.showView.imshow,
      (newValue) => {
        // isOpen.value = newValue
        flag.value = newValue
        if (newValue) {
          ;(async () => {
            getAll()
            // tableData.value = await areaIdDb()
            // getAll()
          })()
        }
      }
    )
    // watch(() => cObj.value.rectangleCoordinates[0], (newValue) => {

    //     console.log('mana 矩形变化---', newValue)

    // })

    const drawArea = () => {
      // isOpen.value = false //暂时关闭弹窗
      // cObj.value.startDrawing(isOpen, callback)
    }

    const handlerEmit = (selectObj) => {
      console.log(selectObj.value)
      cObj.value.deletePoint(selectObj)

    }
    function handleClose() {
      ctx.emit('closeEmit', { whois: 'imshow', status: false })
    }
    const callback = (args) => {
      //框选后的回调函数
      console.log('框选-manager--', args) //绘点
      // cObj.value.drawPoint()
    }

    const getAll = () => {
      areaAll().then((res) => {
        cObj.value.drawRectangle(res.data, pickRectBack)
      })
    }

    const handleCopy = (index, row) => {
      let { tableName, region } = row
      let data = {
        region: JSON.stringify(region),
        tableName: tableName
      }
      dataCopyApi(data).then((res) => {
        console.log('索引copy---')
        pickRectBack(currentRect.value)
      })
      console.log(index, row)
    }

    const handleCheck = async (row) => {
      isOpen.value = false
      isShow.value = true
      let streetDb = { tableName: row.tableName }
      yearApi(streetDb).then(async (res) => {
        // 创建一个对象，键为年份，值为对应年份的日期数组
        var datesByYear = {}
        let yearList =[]
        // 遍历日期数据
        res.data.forEach(function (item) {
          if (item.yearMonth) {
            var year = item.yearMonth.substring(0, 4) // 提取年份
            if (!datesByYear[year]) {
              datesByYear[year] = [] // 如果该年份不存在，则创建一个数组
              yearList.push(year)//储存年份，不带月份查询
            }
            datesByYear[year].push(item.yearMonth) // 将日期添加到对应年份的数组中
          }
        })
        let dataArray = Object.entries(datesByYear).map(([key, value]) => ({ [key]: value }))
        dataArray.sort(function (a, b) {
          let keyA = Object.keys(a)[0]
          let keyB = Object.keys(b)[0]
          return keyA - keyB
        })
        console.log(dataArray)
        console.log(datesByYear)
        let last3 = dataArray //所有
        // let last3 = dataArray.slice(-3) //取最新三年
        for (let m = 0; m < yearList.length; m++) {
          streetDb.yearMonth = yearList[m]
          await streetApi(streetDb).then((res) => {
              cObj.value.drawPoint(res.data, yearList[m]) //日期未排序 yearApi
              console.log('streetApi----')
            })
        }
        


        // for (let j = 0; j < last3.length; j++) {
        //   let d = Object.values(last3[j])[0]
        //   for (let k = 0; k < d.length; k++) {
        //     console.log(d[k])
        //     streetDb.yearMonth = d[k]

        //     await streetApi(streetDb).then((res) => {
        //       cObj.value.drawPoint(res.data, 'streetpoint',) //日期未排序 yearApi
        //       console.log('streetApi----')
        //     })
        //   }
        // }
      })
    }
    const handleDelete = (scope) => {
      let id = scope.row.id
      deleteApi({ id: id }).then((res) => {
        pickRectBack(currentRect.value)
      })
    }
    const deleteArea = () => {
      deleteApi({ region: currentRect.value }).then((res) => {
        pickRectBack(currentRect.value)
      })
    }
    function pickRectBack(rect) {
      if (!currentRect.value) {
        currentRect.value = rect
      }
      let para = { region: rect }
      areaDb(para).then((res) => {
        isOpen.value = true
        tableData.value = res.data
        cObj.value.drawPoint(res.data,'dbpoint')
      })
    }
    onMounted(() => {
      nextTick(() => {
        // cObj.value.drawPoint()
        // cObj.value.drawRectangle()
        console.log('manager---', props)
        console.log('manag33er5---', cObj.value)
      })
    })
    return {
      menu,
      table,
      isShow, //显示色块
      isOpen,
      tableData,
      currentRect,

      handlerEmit,
      handleDelete,
      deleteArea,
      handleCheck,

      handleCopy,
      drawArea,
      handleClose
    }
  }
}
</script>
<style scope>
.menu{
  position: fixed;
    z-index: 11;
    right: 10px;
    width: 100px;
    height: 100px;
    border: 1px solid;
}
.el-drawer__body{
  padding-top: 0px;
}
.el-drawer__header {
    display: flex;
    margin-bottom: 0px;
    padding: 0px;
}
.op {
  left: initial !important;
  width: 200px;
}
.area-mana {
  display: flex;
  margin-bottom: 10px;
}
</style>

<template>
    <div>
        <el-dialog title="街景下载" v-model="isOpen" @close="handleClose">
            <div class="tablOne">
                <el-form :inline="true" :model="form">
                    <el-form-item label="索引库">
                        <el-input v-model="form.library"></el-input>
                    </el-form-item>
                    <el-form-item label="下载年份">
                        <el-date-picker v-model="form.year" type="date" placeholder="选择日期" format="YYYY/MM/DD"
                            value-format="YYYY-MM-DD">
                        </el-date-picker>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary">搜索</el-button>
                    </el-form-item>
                </el-form>
                <div><el-button type="primary">街景下载</el-button><el-button type="primary"
                        @click="handleComparison">下载比对</el-button></div>
                <el-table :data="tableData" stripe border style="width: 100%">
                    <el-table-column prop="date" label="Date" width="180" />
                    <el-table-column prop="name" label="Name" width="180" />
                    <el-table-column prop="address" label="Address" />
                </el-table>
            </div>
            <div class="tableTwo" v-show="comparison">
                <p class="tableTwo-title">下载比对</p>
                <el-button type="primary">全部重新下载</el-button>
                <el-table :data="tableData" stripe border style="width: 100%">
                    <el-table-column type="index" width="50" />
                    <el-table-column prop="date" label="Date" width="180" />
                    <el-table-column prop="name" label="Name" width="180" />
                    <el-table-column prop="address" label="Address" />
                    <el-table-column label="操作" align="center">
                        <template #default="scope">
                            <el-button size="small" type="danger" @click="handleDelete(scope.$index, scope.row)">
                                删除
                            </el-button>
                            <el-button size="small" @click="handleDown(scope.$index, scope.row)">
                                重新下载
                            </el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </el-dialog>
    </div>
</template>
<script>
import { ref, watch } from 'vue'
export default {
    components: {},
    props: {
        showView: Boolean
    },
    emits: ['closeEmit'],
    setup(props, ctx) {

        let isOpen = ref(null)
        const form = ref({ library: '', year: '' })
        const value = ref('2021-10-29')
        const tableData = [
            {
                date: '2016-05-03',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles',
            },
            {
                date: '2016-05-02',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles',
            },
            {
                date: '2016-05-04',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles',
            },
            {
                date: '2016-05-01',
                name: 'Tom',
                address: 'No. 189, Grove St, Los Angeles',
            },
        ]
        const comparison = ref(false)

        watch(() => props.showView.svdshow, (newValue) => {
            isOpen.value = newValue
        })

        const handleDelete = () => {
            console.log('删除--')
        }
        const handleDown = () => {
            console.log('下载--')
        }
        const handleComparison = () => {//下载比对按钮
            comparison.value = true
        }
        function handleClose() {
            comparison.value = false
            ctx.emit('closeEmit', { 'whois': 'svdshow', 'status': false })
        }
        return {
            isOpen,
            form,
            tableData,
            value,
            comparison,//比对table

            handleComparison,
            handleDelete,
            handleDown,
            handleClose
        }
    }
}
</script>
<style>
.tableTwo-title {
    color: var(--el-text-color-primary);
    font-size: var(--el-dialog-title-font-size);
    line-height: var(--el-dialog-font-line-height);
    padding-bottom: var(--el-dialog-padding-primary);
    padding: var(--el-dialog-padding-primary)
}
</style>

<template>
    <div>

        <el-dialog title='索引下载' v-model="isOpen" @close="handleClose">
            <el-form :model="form" label-width="auto" style="max-width: 600px">
                <el-form-item label="范围选择：">
                    <img style="width: 30px;height: 29px;" src="../../assets/street/多边形.png" alt="" srcset=""
                        @click="drawArea">
                </el-form-item>
                <el-form-item label="key值：">
                    <el-input v-model="form.indexValue" />
                </el-form-item>
                <!-- <el-form-item>
                    待下载：{{ downs.waitDown }}已下载：{{ downs.alreadyDown }}
                </el-form-item> -->
                <el-form-item>
                    <el-button type="primary" @click="onSubmit">确定</el-button>
                    <el-button type="primary" @click="onCancel">取消</el-button>
                </el-form-item>
            </el-form>
        </el-dialog>
    </div>
</template>
<script>
// import axios from 'axios'
import { ElMessage } from 'element-plus'
import { panoKeyApi, getIndexApi, getAlreadAPI,indexDownApi } from '../../http/indexDownAPI.js'
import { ref, watch, onMounted, inject } from 'vue'
import  {makeLonlat,areaDb}  from '../../api/tool.js'
export default {
    components: {},
    props: {
        showView: Boolean
    },
    emits: ['closeEmit'],
    setup(props, ctx) {
        const indexData =ref(null)
        let isOpen = ref(null)
        const panoId = ref(null)//街景图key
        const form = ref({
            range: '',//范围选择
            indexValue: '',//图片索引
        })
        const downs = ref({
            waitDown: '10',//等待下载
            alreadyDown: '100'//已下载
        })
        const cesiumCoor = inject('cesiumCoor')//取父组件provid变量
        const cObj = inject('cObj')//取父组件provid变量
        const manaRef = inject('manaRef')//取父组件provid变量

        watch(() => props.showView.idshow, (newValue) => {
            // drawArea()
            if (newValue) {
                isOpen.value = newValue//取消弹窗，直接画区域
                loadGoogleMapsScript().then(() => {
                    getPanoId()
                })
                // messages('框选开启','success')
                // drawArea()
            } else {
                // messages('框选关闭', 'warning')
                // cObj.value.closeListen()
                // cObj.value.removeEPall()
            }
        })

        const drawArea = () => {
            cObj.value.removeEPall()//清除entity
        cObj.value.removeAll1()//清除primitive
            isOpen.value = false //暂时关闭弹窗
            cObj.value.startDrawing(null, callback)//取消弹窗，直接画区域
        }
        const callback = (args) => {
            //框选后的回调函数
            console.log('框选---', args) //绘点
            // onSubmit()
            // cObj.value.drawPoint()
        }
        function onSubmit() {
            let region = quyu()
            let data = {
                keyName:'122kxY36j_9RBB_H48_P8Q',
                region: JSON.stringify(region),
                lon:"121.4236441",
                lat:"25.2021338"
            }
            indexDownApi(data).then(res => {
                console.log(res.data)
            })
        }

        function onSubmit1() {//保存框选区域
            console.log(cesiumCoor)//或cObj.value 矩形经纬度
            let p = cesiumCoor.value[cesiumCoor.value.length - 1]
            let quyu = []
            quyu.push(p.west, p.south, p.east, p.north)
            let region = makeLonlat(quyu)
            // debugger
            let data = {
                keyName: panoId.value,
                // lat: '25.078430',
                // lon: '121.571720',
                // region: "[{'lon': '121.531527','lat': '25.022567'},{'lon': '121.611206','lat': '25.022567'},{'lon': '121.611206','lat': '25.110498'},{'lon': '121.531527','lat': '25.110498'},{'lon': '121.531527','lat': '25.022567'}]",
                region: JSON.stringify(region),
                storageAddress: 'H:\\street-new\\'
            }
            panoKeyApi(data).then((res) => {
                indexData.value = res.data  
                cObj.value.drawPoint(res.data)
            })
            // setInterval(() => {
            //     indexCount()
            //     alreadyCount()
            // }, 3000)

            console.log('submit!')
        }
        const alreadyCount = () => {//带下载
            getAlreadAPI().then(res => {
                downs.value.alreadyDown = res.data
            })
        }
        const indexCount = () => {//已下载
            getIndexApi().then(res => {
                downs.value.waitDown = res.data
            })
        }
        function messages(msg,type){
            ElMessage({
                showClose: true,
                message: msg,
                type: type
            });
        }
        function onCancel() {
            console.log('取消!')
        }
        function handleClose() {
            ctx.emit('closeEmit', { 'whois': 'idshow', 'status': false })
        }
        const loadGoogleMapsScript = () => {
            return new Promise((resolve, reject) => {
                if (typeof google !== 'undefined' && google.maps) {
                    resolve()
                    return
                }
                const ggScript = document.createElement('script')
                ggScript.src = 'https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false'
                ggScript.async = true
                ggScript.onload = resolve
                ggScript.onerror = reject
                document.head.appendChild(ggScript)
            })
        }
        const getPanoId = () => {//获取框选街景key
            const panoClient = new google.maps.StreetViewService()//25.078430 121.571720  25.1862566, 121.4185904
            let lonlat = new google.maps.LatLng(25.0864729, 121.5750668)
            panoClient.getPanoramaByLocation(lonlat, 50, function (result, status) {
                if (status === google.maps.StreetViewStatus.OK) {
                    panoId.value = result.location.pano;
                    console.log('街景图key---', panoId.value)
                    form.value.indexValue = result.location.pano
                } else {
                    if (self.onNoPanoramaData) self.onNoPanoramaData(status);
                    self.throwError('由于以下原因，无法检索全景图: ' + status);
                }
            })
        }

        function quyu() {
        let rect = cObj.value.rectangleCoordinates
        if (rect.length > 0) {
            let quyu = []
            // let big = cObj.value.pickArea
            let p = rect[rect.length - 1]
            quyu.push(p.west, p.south, p.east, p.north)
            let region = makeLonlat(quyu)
            console.log('-----', region)
            return region
        }
        }

        onMounted(() => {
            console.log('indexDown---', cObj.value,manaRef.value)//地球组件中对象
            loadGoogleMapsScript().then(res => {
                console.log(res)
            })
        })
        return {
            form,
            drawArea,
            onSubmit,
            onCancel,
            isOpen,
            cesiumCoor,
            downs,

            handleClose,
            loadGoogleMapsScript,
        }
    }
}
</script>
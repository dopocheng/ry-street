<script setup>
import TheWelcome from '../components/TheWelcome.vue'
import StreetView from './StreetView/homeIndex.vue'  
</script>

<template>
  <main>
    <StreetView />
  </main>
</template>
